public class Methoden {   

    /* *** Aufgabenteil (a) *** */

 
    public static void testMehrheit(){
	
    }

    /* *** Aufgabenteil (b) *** */


    public static void testMonoton(){
	int[] a = {-1,0,1};
 	int[] b = {2,2,2,2};
 	int[] c = {-1,-2,-3};
 	int[] d = {3,2};
	int[] e = {0};

	
    }

    public static void main(String[] args){
	testMehrheit();
	testMonoton();
    }
}
