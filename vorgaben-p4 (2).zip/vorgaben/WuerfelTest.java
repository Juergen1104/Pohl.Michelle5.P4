public class WuerfelTest {
    public static void main(String[] args){
	int n = 3;
	Wuerfel[] wuerfel = new Wuerfel[n];

	/* *** Aufgabenteil (b) *** */

	System.out.println("---------------");


    }
}
