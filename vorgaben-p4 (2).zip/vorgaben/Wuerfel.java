public class Wuerfel {
    public static int max = 6;  // maximale Augenzahl auf dem Wuerfel
    public int nr;
    public int wert;

    /* *** Aufgabenteil (a) *** */

}
